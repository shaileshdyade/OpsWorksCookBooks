name "test_suite"
description "runs cookbook tests"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends 'opsworks_commons'
