name        "ssh_users"
description 'Create system users for OpsWorks users with personal SSH keys'
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends "opsworks_commons"
depends 'opsworks_initial_setup'
