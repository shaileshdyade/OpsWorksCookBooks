default['s3_file']['rest-client']['version'] = '1.6.7'
