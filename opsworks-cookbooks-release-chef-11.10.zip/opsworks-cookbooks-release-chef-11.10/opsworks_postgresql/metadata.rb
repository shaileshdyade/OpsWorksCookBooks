name        "opsworks_postgresql"
description "Installs and configures the Postgresql client"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

recipe "postgresql::client_install", "Installs the Postgresql client"
