name        "mod_php5_apache2"
description "Installs/Configures Apache with mod_php5"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends "apache2"
depends "deploy"
