default['opsworks_aws_flow_ruby']['user_agent_prefix'] = 'ruby-flow-opsworks'
default['opsworks_aws_flow_ruby']['minimum_flow_gem_version'] = '2.0.1'
