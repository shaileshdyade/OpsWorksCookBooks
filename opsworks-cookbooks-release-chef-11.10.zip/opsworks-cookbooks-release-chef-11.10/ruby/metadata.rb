name        "ruby"
description "Installs Ruby"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends 'opsworks_bundler'
depends 'opsworks_rubygems'
depends 'opsworks_initial_setup'
depends 'opsworks_commons'
