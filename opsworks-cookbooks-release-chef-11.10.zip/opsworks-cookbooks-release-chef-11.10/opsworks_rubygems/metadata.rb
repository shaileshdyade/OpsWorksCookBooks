name        "opsworks_rubygems"
description "Installs Rubygems"
maintainer  "AWS OpsWorks"
license     "Apache 2.0"
version     "1.0.0"

depends 'opsworks_initial_setup'
