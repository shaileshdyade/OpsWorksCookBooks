service 'ganglia-monitor' do
  action [:enable, :nothing]
end
