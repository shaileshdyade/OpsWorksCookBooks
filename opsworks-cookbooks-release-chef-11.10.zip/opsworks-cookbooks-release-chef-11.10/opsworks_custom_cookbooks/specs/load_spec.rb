require 'minitest/spec'

describe_recipe 'opsworks_custom_cookbooks::load' do
  include MiniTest::Chef::Resources
  include MiniTest::Chef::Assertions

end
